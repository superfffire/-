function zhuanjiao = y_z()
%% 压力角导入
alpha=xlsread('故障.xlsx', 1, 'B2:B302');
zhuanjiao=tand(alpha)-tand(11.4950);
end

